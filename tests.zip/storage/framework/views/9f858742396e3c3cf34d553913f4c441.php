<div 
    class="fixed flex justify-center items-center mx-auto z-40 top-0 left-0 w-full h-screen"
    role="dialog"
    tabindex="-1"
    x-show="registerOpen"
    x-on:click.away="registerOpen = false"
    x-cloak
    x-transition
    >
    <div x-on:click="registerOpen = false" class="fixed left-0 top-0 w-full h-screen bg-black/50"></div>
    <form action="<?php echo e(route('store')); ?>" method="post" class="max-w-max mx-auto z-50 flex flex-row gap-1 justify-center">
        <?php echo csrf_field(); ?>
        <div class="w-96 bg-white shadow-md border border-gray-200 rounded-lg p-4 sm:p-6 lg:p-8 dark:bg-gray-800 dark:border-gray-700">
            <div class="space-y-6" >
                <h3 class="text-xl font-medium text-gray-900 dark:text-white">Register</h3>

                <div>
                    <label for="name" class="text-sm font-medium text-gray-900 block mb-2 dark:text-gray-300">Your Name</label>
                    <input type="text" name="name" id="name" class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white" placeholder="name here" required value="<?php echo e(old('name')); ?>">
                    <?php if($errors->has('name')): ?>
                        <span class="text-sm font-medium text-gray-900 block mb-2 dark:text-gray-300"><?php echo e($errors->first('name')); ?></span>
                    <?php endif; ?>
                </div>

                <div>
                    <label for="email" class="text-sm font-medium text-gray-900 block mb-2 dark:text-gray-300">Email Address</label>
                    <input type="email" name="email" id="email" class="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white" placeholder="name@company.com" required value="<?php echo e(old('email')); ?>">
                    <?php if($errors->has('email')): ?>
                        <span class="text-sm font-medium text-gray-900 block mb-2 dark:text-gray-300"><?php echo e($errors->first('email')); ?></span>
                    <?php endif; ?>
                </div>

                <div>
                    <label for="password" class="text-sm font-medium text-gray-900 block mb-2 dark:text-gray-300">Password</label>
                    <input type="password" name="password" id="password" placeholder="••••••••" class="<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white" required>
                    <?php if($errors->has('password')): ?>
                        <span class="text-sm font-medium text-gray-900 block mb-2 dark:text-gray-300"><?php echo e($errors->first('password')); ?></span>
                    <?php endif; ?>
                </div>

                <div>
                    <label for="password_confirmation" class="text-sm font-medium text-gray-900 block mb-2 dark:text-gray-300">Confirm Password</label>
                    <input type="password" id="password_confirmation" name="password_confirmation" placeholder="••••••••" class="<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white" required>
                </div>

                <button x-on:click="regisDetail = !regisDetail" class="w-full text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                    Next
                </button>
                <p class="text-sm font-light text-gray-500 dark:text-gray-400">
                    Have an account? <button x-on:click="loginOpen = true, registerOpen = false" class="font-medium text-primary-600 hover:underline dark:text-primary-500">Login</button>
                </p>
            </div>
        </div>
        
        <div x-show="regisDetail" class="w-96 bg-white shadow-md border border-gray-200 rounded-lg p-4 sm:p-6 lg:p-8 dark:bg-gray-800 dark:border-gray-700">
            <div class="space-y-6" >
                <h3 class="text-xl font-medium text-gray-900 dark:text-white">Your Detail Address</h3>

                <div>
                    <label for="telp" class="text-sm font-medium text-gray-900 block mb-2 dark:text-gray-300">Telephone</label>
                    <input type="number" name="telp" id="telp" class="<?php $__errorArgs = ['telp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white" placeholder="08xxxxxxxxxx" required value="<?php echo e(old('telp')); ?>">
                    <?php if($errors->has('telp')): ?>
                        <span class="text-sm font-medium text-gray-900 block mb-2 dark:text-gray-300"><?php echo e($errors->first('telp')); ?></span>
                    <?php endif; ?>
                </div>

                <div>
                    <label for="address" class="text-sm font-medium text-gray-900 block mb-2 dark:text-gray-300">Detail Address</label>
                    <textarea name="address" id="address" class="<?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white" required><?php echo e(old('address')); ?></textarea>
                    <?php if($errors->has('address')): ?>
                        <span class="text-sm font-medium text-gray-900 block mb-2 dark:text-gray-300"><?php echo e($errors->first('address')); ?></span>
                    <?php endif; ?>
                </div>

                <input type="submit" class="w-full text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800" value="Register">
            </div>
        </div>
    </form>
</div><?php /**PATH C:\laragon\www\PressIt\resources\views/auth/register.blade.php ENDPATH**/ ?>