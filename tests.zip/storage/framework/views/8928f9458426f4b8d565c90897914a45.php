<td
    <?php echo e($attributes->class(['filament-tables-reorder-cell w-4 whitespace-nowrap px-4'])); ?>

>
    <?php echo e($slot); ?>

</td>
<?php /**PATH C:\laragon\www\PressIt\vendor\filament\tables\src\/../resources/views/components/reorder/cell.blade.php ENDPATH**/ ?>