<div
    <?php echo e($attributes->class([
            'filament-forms-field-wrapper-helper-text text-sm text-gray-600',
            'dark:text-gray-300' => config('forms.dark_mode'),
        ])); ?>

>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\laragon\www\PressIt\vendor\filament\forms\src\/../resources/views/components/field-wrapper/helper-text.blade.php ENDPATH**/ ?>